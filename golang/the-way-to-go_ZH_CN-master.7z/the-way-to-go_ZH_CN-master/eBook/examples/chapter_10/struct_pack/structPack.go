package structPack

type ExpStruct struct {
	Mi1 int
	Mf1 float32
}
